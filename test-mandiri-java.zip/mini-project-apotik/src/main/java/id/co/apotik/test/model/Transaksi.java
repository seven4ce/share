package id.co.apotik.test.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.criteria.Join;

@Entity
@Table(name="transaksi")
public class Transaksi {
	
	@Id
	@Column(name="id_transaksi")
	private long idTransaksi;
	
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="id_item")
	private Item item;
	
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="id_harga")
	private Harga harga;


	public long getIdTransaksi() {
		return idTransaksi;
	}


	public void setIdTransaksi(long idTransaksi) {
		this.idTransaksi = idTransaksi;
	}


	public Item getItem() {
		return item;
	}


	public void setItem(Item item) {
		this.item = item;
	}


	public Harga getHarga() {
		return harga;
	}


	public void setHarga(Harga harga) {
		this.harga = harga;
	}
	
	
	
	
	
	
	
	

}
