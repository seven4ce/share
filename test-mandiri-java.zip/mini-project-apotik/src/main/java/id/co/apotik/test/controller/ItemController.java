package id.co.apotik.test.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import id.co.apotik.test.model.Item;
import id.co.apotik.test.repository.ItemRepository;

@Service
@RestController
@RequestMapping("/item")
public class ItemController {

	@Autowired
	private ItemRepository itemRepository;
	
	@GetMapping("/getAll")
	public List<Item> getAllItem(){		
		List<Item> harga = new ArrayList<>();		
		harga = itemRepository.findAll();		
		return harga;
		
	}
	
	@GetMapping("/getBy")
	public Item getById(@RequestParam("/idItem") long idHarga) {
		
		Item harga = new Item();		
		harga = itemRepository.findOne(idHarga);		
		return harga;		
		
	}

}
