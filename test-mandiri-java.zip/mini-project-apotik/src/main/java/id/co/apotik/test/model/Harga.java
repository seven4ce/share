package id.co.apotik.test.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="harga")
public class Harga {
	
	@Id
	@Column(name="id_harga")
	private long idHarga;
	
	@Column
	private long harga;
	
	@Column
	private String curency;
	

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="id_Harga")
	@JsonIgnore
	private Transaksi trx;

	public Transaksi getTrx() {
		return trx;
	}

	public void setTrx(Transaksi trx) {
		this.trx = trx;
	}

	public long getIdHarga() {
		return idHarga;
	}

	public void setIdHarga(long idHarga) {
		this.idHarga = idHarga;
	}

	public long getHarga() {
		return harga;
	}

	public void setHarga(long harga) {
		this.harga = harga;
	}

	public String getCurency() {
		return curency;
	}

	public void setCurency(String curency) {
		this.curency = curency;
	}
	
	
	
	
	
	

}
