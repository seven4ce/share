package id.co.apotik.test.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="harga")
public class Item {
	
	@Id
	@Column(name="id_item")
	private long idItem;
	
	@Column(name = "nama_item")
	private String namaItem;
	

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="id_harga")
	@JsonIgnore
	private Harga trx;



	public Harga getTrx() {
		return trx;
	}

	public void setTrx(Harga trx) {
		this.trx = trx;
	}

	public long getIdItem() {
		return idItem;
	}

	public void setIdItem(long idItem) {
		this.idItem = idItem;
	}

	public String getNamaItem() {
		return namaItem;
	}

	public void setNamaItem(String namaItem) {
		this.namaItem = namaItem;
	}
	
	
	
	

}
