package id.co.apotik.test;

public class ArrayTest {

	public static void main(String[] args) {

		int[] arrayA = {20,10,40,10,30};
		int[] arrayB = {30,10,70,50,30};
		
		


	}

}
